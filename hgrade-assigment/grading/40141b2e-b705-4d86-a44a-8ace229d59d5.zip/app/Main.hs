-- | Dieses Modul enthält den Einstiegspunkt, um die Applikation zu starten.
module Main where

import qualified Hgrade

-- |Haupteinstiegspunkt, delegiert weiter an die main-Funktion im Modul Hgrade
main :: IO ()
main = Hgrade.main  
