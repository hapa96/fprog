
-- | Dieses Modul enthält Funktionen um HTML zu generieren.

module CreateHtml where

-- | Diese Funktion wird verwendet, um die spitzen Klammern vor Wörter zu setzen, um HTML-Notationen zu erstellen
hilfsHTML :: String -> String -> String -> String
hilfsHTML element endelem b = ("<"++element++">") ++ b ++ "</"++endelem ++">"

-- | Diese Funktion erstellt einen Absatz in einem HTML-Dokument
p :: String -> String 
p t  = hilfsHTML "p" "p" t

-- | Diese Funktion erstellt eine Überschrift in einem  HTML-Dokument
h1 :: String -> String 
h1 t = hilfsHTML "h1" "h1" t

-- | Diese Funktion legt den Stil einer Tabelle fest in einem  HTML-Dokument
style ::  String
style = hilfsHTML "style" "style" "table, th, td {border: 1px solid black;border-collapse: collapse;}"

-- | Diese Funktion erstellt eine Aufzählungsliste in einem  HTML-Dokument
ul :: String -> String 
ul t = hilfsHTML "ul" "ul" t

-- | Diese Funktion erstellt einen Listeneintrag in einem  HTML-Dokument
li :: String -> String 
li t = hilfsHTML "li" "li"t

-- | Diese Funktion erstellt die Doctype-Deklaration am Anfang eines HTML-Dokuments
doctype :: String
doctype = hilfsHTML "!doctype html" "" ""

-- | Diese Funktion erstellt das HTML-Element am Anfang des HTML-Dokuments
writehtml :: String -> String
writehtml t = hilfsHTML "html lang='en'" "html" t

-- | Diese Funktion erstellt ein head-Element in einem  HTML-Dokument
writehead :: String -> String 
writehead t = hilfsHTML "head" "head" t

-- | Diese Funktion erstellt ein body-Element in einem  HTML-Dokument
writebody :: String -> String 
writebody t = hilfsHTML "body" "body" t

-- | Diese Funktion erstellt einen Hyperlink in einem  HTML-Dokument
a :: String -> String -> String 
a link name = hilfsHTML ("a "++link) "a" name

-- | Diese Funktion erstellt eine Zelle in einer HTML-Tabelle
td :: String -> String 
td t = hilfsHTML "td" "td"t

-- | Diese Funktion erstellt ein Histogram in einer HTML-Tabelle
tdHistogram :: String -> String 
tdHistogram color= hilfsHTML ("td bgcolor='"++color++"' style='height:20px;width:20px'") "td" ""

-- | Diese Funktion erstellt eine Zeile in einer HTML-Tabelle
tr :: String -> String 
tr t = hilfsHTML "tr" "tr" t

-- | Diese Funktion erstellt Spalte in einer HTML-Tabelle
th :: String
th = hilfsHTML "th width =80px" "th" ""

-- | Diese Funktion erstellt für jeden Eintrag in einer Liste eine Spalte in einer HTML-Tabelle
thList :: [String] -> String
thList (b:bs) = (hilfsHTML "th width =80px" "th" b) ++ thList bs
thList [] = ""

-- | Diese Funktion erstellt für jeden Eintrag in einer Liste eine Zelle in einer HTML-Tabelle
tdList :: [String] -> String
tdList (b:bs) = (hilfsHTML "td" "td" "1") ++ tdList bs
tdList [] = ""

-- | Diese Funktion erstellt ein HTML-Formular
formular :: [String] -> String
formular (b:bs)= hilfsHTML ("form action='/grading_page' method='post'") "form" ((label "author_ID" "Author:") ++ (input "author_ID" "Author") ++(label "grader_ID" "Grader:") ++ (input "grader_ID" "Grader")++(labelForCriteria (b:bs)) ++ submit)
formular []="" 

-- | Diese Funktion erstellt ein Label in einem HTML-Formular
label :: String -> String -> String
label for name = hilfsHTML ("label for='"++for++"'") "label" name

-- | Diese Funktion erstellt für jeden Eintrag in einer Liste ein Label in einem HTML-Formular
labelForCriteria :: [String]-> String 
labelForCriteria (b:bs) = (hilfsHTML ("label for='"++b++"'") "label" (b++":")) ++ (input b b) ++ labelForCriteria bs
labelForCriteria [] = ""

-- | Diese Funktion erstellt ein Input-Feld in einem HTML-Formular
input :: String -> String -> String 
input idn name = (hilfsHTML ("input type='text' id='"++idn++"' name='"++name++"'") "input" "") ++ br

-- | Diese Funktion erstellt einen Submit-Button in einem HTML-Formular
submit :: String
submit = hilfsHTML "input type='submit' value='Send'" "input" ""

-- | Diese Funktion erstellt einen Zeilenumbruch in einem HTML-Dokument
br :: String
br = "<br><br>" 

-- | Diese Funktion erstellt das Grundgerüst für eine HTML-Tabelle
table :: String -> String
table t = hilfsHTML "table" "table" t
