-- | In diesem Modul werden die Bewertungskriterien festgelegt
module Criteria where

-- | In dieser Liste können die Bewertungskriterien festgelegt werden. Achtung! Die Anpassung erfolgt nur im Formular und bei der Kriterienübersicht auf der Bewertungsseite. In der Datei werden die "fixen" Kriterien gespeichert.
criteria :: [String]
criteria = ["N1", "N2", "F1", "F2", "F3", "F4"]
