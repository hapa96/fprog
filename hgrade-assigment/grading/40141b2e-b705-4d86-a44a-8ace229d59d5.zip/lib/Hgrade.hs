{-# LANGUAGE OverloadedStrings #-}
-- | Dieses Modul definiert, was beim Aufruf bestimmter Internetadressen angezeigt wird und welche Funktionen dem Nutzer zur Verfügung stehen.

module Hgrade where

import           CreateHtml (writehtml,writehead,writebody,h1,ul,li,a,tr,formular,style,table,th,thList,doctype)
import           Criteria(criteria)
import           Utilities(linkToGrading,checkFolderandWrite,createList,folderElements,createRow)
import           Web.Scotty
import           Control.Monad.IO.Class (liftIO)
import           Network.Wai.Middleware.RequestLogger ( logStdoutDev )
import           System.Directory (listDirectory)
import qualified Data.Text.Lazy as T


-- | Diese Funktion startet den Webserver und bestimmt, was beim Aufruf bestimmter Internetadressen angezeigt wird
main :: IO ()
main = do
  putStrLn "Good Luck!"
  scotty 4000 $ do
    middleware logStdoutDev

    get "/" $ do
      html (T.pack (doctype ++writehtml (writehead (writebody (h1 "Hgrade - Peergrading in Haskell")++ul (linkToGrading (li (a "href= http://localhost:4000/authors" "Grading Overview")) (li (a "href= http://localhost:4000/grade" "Submit Grading")) )))))

    get "/authors" $ do
      folder <- liftIO (listDirectory "data") 
      html (T.pack (doctype ++ writehtml (writehead ""++ writebody ((h1 "Authors")++(ul ((folderElements folder)))) )))

    get "/grade" $ do
      html (T.pack (doctype ++ writehtml ((writehead "")++ (writebody ((h1 "Grade")++ (formular Criteria.criteria ))))))

    get "/authors/:authorname" $ do
      authorName <- param "authorname"
      graders <- liftIO(listDirectory ("data/"++ authorName))
      html (T.pack (doctype ++writehtml ((writehead style)++writebody (h1 ("Author: "++authorName))++(table (tr (th ++ (thList Criteria.criteria) )++((createRow graders authorName)))))))
  
    post "/grading_page" $ do
      author <- param "Author"
      grader <- param "Grader"
      n1 <- param "N1"
      n2 <- param "N2"
      f1 <- param "F1"
      f2 <- param "F2"
      f3 <- param "F3"
      liftIO (checkFolderandWrite ("data/"++author) ("data/"++author++"/"++grader) (show (createList n1 n2 f1 f2 f3)))
      html (T.pack (doctype ++ writehtml (writehead (writebody (h1 "Hgrade - Peergrading in Haskell")++ul (linkToGrading (li (a "href= http://localhost:4000/authors" "Grading Overview")) (li (a "href= http://localhost:4000/grade" "Submit Grading")) )))))

