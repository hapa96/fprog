
-- | Dieses Modul enthält hilfreiche Funktionen
module Utilities where

import           System.Directory (createDirectoryIfMissing)
import           Data.List(sort)
import           Criteria(criteria)
import           CreateHtml (li,a,td,tr,style,table,tdHistogram,tdList)

-- | Diese Funktion überprüft, ob ein bestimmter Ordner schon existiert, falls ja wird ein File in dem Ordner erstellt, falls nicht wird der Ordner zuvor erstellt.
checkFolderandWrite :: String -> String -> String -> IO ()
checkFolderandWrite path file content = do
  createDirectoryIfMissing True path
  writeFile file content

-- | Diese Funktion ermittelt den Median aus einer Liste von Integer-Zahlen
getMedian :: [Integer] -> Double
getMedian xs | odd len = fromIntegral ((sort xs) !! (len `div` 2))
             | even len = fromIntegral( (((sort xs) !! (len `div` 2)) + ((sort xs) !! ((len `div` 2)-1)))) / 2
                  where len = length xs

-- | Diese Funktion ermittelt den Median aus  einer Liste von Listen mit Integer-Zahlen
getMedianForList :: [[Integer]] ->  [Double]
getMedianForList ((a:as) : (b:bs))=doubleAsList(getMedian (a:as))++ getMedianForList (b:bs)
getMedianForList ((a:as) : [])=doubleAsList(getMedian (a:as))
getMedianForList ((a:as) : (b:[]))=doubleAsList(getMedian (a:as))++ getMedianForList ([b])

-- | Diese Funktion macht aus einer Double-Zahl eine List von einer Double-Zahl
doubleAsList :: Double ->  [Double]
doubleAsList  b = [b]  

-- | Diese Funktion macht aus einer List von Spalten eine Liste aus Zeilen
colsToRows :: [[a]] -> [[a]]
colsToRows [[]] = []
colsToRows ([] : xs) = colsToRows xs
colsToRows cols = (map head cols) : colsToRows (map tail cols)

-- | Diese Funktion erstellt aus 5 Integers eine Liste von Integers
createList :: Integer -> Integer -> Integer -> Integer -> Integer -> [Integer]
createList  b c d e f = [b, c, d, e, f]

-- | Diese Funktion erstellt ein HTML-Histogramm
histogram :: [Int] -> String
histogram [] = ""
histogram (b:bs) = style ++ table (tr (getConcatString (getColor (length (b:bs)) (frequency 0 (b:bs))) ) ++tr (getConcatString (getColor (length (b:bs)) (frequency 1 (b:bs))) )++tr (getConcatString (getColor (length (b:bs)) (frequency 2 (b:bs))) ))

-- | Diese Funktion berechnet, wie oft ein Element in einer Liste vorkommt
frequency :: Ord a => a -> [a] -> Int
frequency _ [] = 0
frequency x list = sum $ map (\a -> 1) $ filter (== x) list

-- | Diese Funktion bestimmt, wleche Farbe in einem Histogramm vorhanden sein soll
getColor :: Int -> Int -> [String]
getColor total 0    = (replicate total (tdHistogram "white"))
getColor total freq = (replicate (subtract freq total) (tdHistogram "white")) ++ (replicate freq (tdHistogram "black"))

-- | Diese Funktion konkatiniert alle Strings aus einer Liste zu einem einzigen String
getConcatString :: [String] -> String
getConcatString [] = []
getConcatString (b:bs) = b ++ getConcatString bs

-- | Diese Funktion erstellt Hyperlinks für alle Elemente aus einer Liste
folderElements :: [String] ->  String
folderElements [] = ""
folderElements [i] = li (a ("href=http://localhost:4000/authors/"++i) i) 
folderElements (i:is) =  li (a ("href=http://localhost:4000/authors/"++i) i) ++ folderElements is

-- | Diese Funktion konkatiniert zwei Strings
linkToGrading :: String -> String -> String
linkToGrading b c = b ++ c

-- | Diese Funktion erstellt für jeden Eintrag in einer Liste eine Zeile in einer Tabelle
createRow :: [String] -> String -> String
createRow [] _ = ""
createRow (i:is) b = tr (td i ++ (tdList criteria)) ++ createRow is b