-- | Dieses Modul testet einige wichtige Funktionen mit UnitTests

module Main (main) where

import Hgrade.Example (unlines')
import Utilities (getMedian, colsToRows,histogram,frequency,getColor,getConcatString,getMedianForList)
import Test.Tasty
import Test.Tasty.HUnit


-- | Diese Funktion ist der Haupteinstiegspunkt der UnitTests und startet die Tests
main :: IO ()
main = defaultMain tests

-- | Diese Funktion startet die UnitTests
tests :: TestTree
tests = testGroup "Tests" [unitTests]

-- | Diese Funktion enthält die verschiedenen UnitTests
unitTests :: TestTree
unitTests = testGroup "Unit tests"
  [ testCase "unlines' empty list" $
      unlines' [] @?= "",

    testCase "unlines' singleton list" $
      unlines' ["hello"] @?= "hello",

    testCase "unlines' larger list" $
      unlines' ["hello","world"] @?= "hello\nworld", 

    testCase "median even list" $
      getMedian [1,2] @?= 1.5,

    testCase "median odd list" $
      getMedian [1,3,2] @?= 2,

    testCase "median for several odd lists" $
      getMedianForList [[1,2,3], [5,3,4]] @?= [2,4],

    testCase "median for odd and even lists" $
      getMedianForList [[3,4],[1,5,2]] @?= [3.5,2],

    testCase "colsToRows list" $
      colsToRows [[1,2,3], [4,5,6]] @?= [[1,4],[2,5],[3,6]],

    testCase "colsToRows onelistempty" $
      colsToRows [[],[1,2,3]] @?= [[1],[2],[3]],

    testCase "frequency" $
      frequency 1 [0,1,1] @?= 2,

    testCase "getColor" $
      getColor 3 2 @?= ["<td bgcolor='white' style='height:20px;width:20px'></td>","<td bgcolor='black' style='height:20px;width:20px'></td>","<td bgcolor='black' style='height:20px;width:20px'></td>"],
    
    testCase "getConcatString" $
      getConcatString ["hallo","welt"] @?= "hallowelt",

    testCase "drawHistogramNo3" $
     histogram [0,1,1] @?=("<style>table, th, td {border: 1px solid black;border-collapse: collapse;}</style><table><tr><td bgcolor='white' style='height:20px;width:20px'></td><td bgcolor='white' style='height:20px;width:20px'></td><td bgcolor='black' style='height:20px;width:20px'></td></tr>"++"<tr><td bgcolor='white' style='height:20px;width:20px'></td><td bgcolor='black' style='height:20px;width:20px'></td><td bgcolor='black' style='height:20px;width:20px'></td></tr>"++"<tr><td bgcolor='white' style='height:20px;width:20px'></td><td bgcolor='white' style='height:20px;width:20px'></td><td bgcolor='white' style='height:20px;width:20px'></td></tr></table>"),

    testCase "drawHistogramAllNumbersOneTime" $
      histogram [0,1,2] @?=("<style>table, th, td {border: 1px solid black;border-collapse: collapse;}</style><table><tr><td bgcolor='white' style='height:20px;width:20px'></td><td bgcolor='white' style='height:20px;width:20px'></td><td bgcolor='black' style='height:20px;width:20px'></td></tr>"++"<tr><td bgcolor='white' style='height:20px;width:20px'></td><td bgcolor='white' style='height:20px;width:20px'></td><td bgcolor='black' style='height:20px;width:20px'></td></tr>"++"<tr><td bgcolor='white' style='height:20px;width:20px'></td><td bgcolor='white' style='height:20px;width:20px'></td><td bgcolor='black' style='height:20px;width:20px'></td></tr></table>")
  ]

