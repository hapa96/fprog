{-# LANGUAGE OverloadedStrings #-}

module Hgrade where

import Web.Scotty
    ( file, get, html, middleware, param, post, scotty, ActionM )
import           Control.Monad.IO.Class (liftIO)
import           Network.Wai.Middleware.RequestLogger ( logStdoutDev )
import qualified Data.Text.Lazy as T
import System.Directory ( listDirectory )
import Hgrade.HtmlDomBuilder
    ( defaultHtmlPage,
      br,
      divHtml,
      h1,
      h2,
      p,
      ul,
      li,
      a,
      lia,
      table,
      tr,
      th,
      td,
      tdBgColorBox,
      formHtml,
      submitButton,
      inputLabel )
import Hgrade.Utilies
    ( mapWithTwo,
      colsToRows,
      median,
      histogram,
      histogramToPlotValue,
      nrRandInt,
      getColor, createNewDirectory )
import System.Environment ( getArgs )
import Control.Monad (replicateM)

-- | Main: Kontrolliert die Argumente via CLI für ein match, ob "Demo Daten" zusätzlich generiert werden sollen.
-- Startet schlussendlich den WebClient
main :: IO ()
main = do
  demoPattern <- getArgs 
  if elem "-demo" demoPattern
    then generateDemoData
    else return ()
  startWebClient   

-- | Generieren der Demo-Daten mit randomisierten Gradings-Values
generateDemoData :: IO ()
generateDemoData = do
    putStrLn "\n\n ----- Generate Demo Data ------ \n"
    let dataPath = "data/"  
    createNewDirectory dataPath
    let nr1to4 = map show [1..4]
    let folders = map (\x -> dataPath ++ "author" ++ x) nr1to4
    mapM_ createNewDirectory folders
    mapM_ writeDemoFile nr1to4
    putStrLn "\n ----- Demo Data are written ------ \n\n"

-- | WriteDemoFile ist eine Helferfunktion. Erstellt eine Liste mit Random-Nummern und schreibt sie in eine Datei.
-- Nimmt einen String (bzw. eine Nummer) und concatiniert es mit der Folder- und File-Name
writeDemoFile :: String-> IO ()
writeDemoFile nr = do
  randomValuesList <- replicateM 5 nrRandInt
  print randomValuesList
  liftIO $ writeFile ("data/author" ++ nr ++"/grader"++ nr ++".txt") (show randomValuesList)

-- | Der WebClient: die REST-Schnittstelle zum Browser. Behandelt die Logik und für bei GET/POST die passende Funktionen aus.
startWebClient :: IO ()
startWebClient = scotty 4000 $ do
    middleware logStdoutDev

    get "/" startPageHtml

    get "/authors" authorsHtml

    get "/authors/:authorname" $ do 
        authorname <- param "authorname"
        gradingAuthorHtml authorname
  
    post "/grade" $ do
      author <- param "Author"
      grader <- param "Grader"
      gradingParams <- mapM ( param . T.pack ) criteriaList
      let gradings = map (\x -> x :: Int) gradingParams
      let graderFilePath = "data/" ++ author 
      createNewDirectory graderFilePath
      liftIO $ writeFile (graderFilePath ++ "/"++ grader ++".txt") (show gradings)
      html $ T.pack $ defaultHtmlPage [ 
                                        h1["Hi " ++  grader], 
                                        p["Thank you for your rating"],
                                        a ("/authors/" ++ author) ("Checkout " ++ author ++ "'s gradings") 
                                      ]

    get "/grade" submitHtml

    get "/static/styles.css" $ file "static/styles.css"
  
-- | Die StarterPage bzw. LandingPage. Bei Url GET "/" und rendert das HTML
startPageHtml :: ActionM()
startPageHtml = html $ T.pack $ defaultHtmlPage [  
                                                  h1["Hgrade - Peergrading in Haskell"],
                                                  ul[
                                                    li[
                                                      a "/authors" "Grading Overview"
                                                    ],
                                                      li[
                                                      a "/grade" "Submit Grading"
                                                    ]
                                                  ]
                                                ]  
 
-- | Die GradingPage. Bei Url GET "/grade" und redert das HTML
submitHtml :: ActionM() 
submitHtml = do
  html $ T.pack $ defaultHtmlPage [ 
                                    h1 [ "Grade" ],
                                    formHtml "/grade" "post" 
                                      [ 
                                        inputLabel "text" "Author_ID" "Author" "Author:",
                                        br,
                                        inputLabel "text" "Grader_ID" "Grader" "Grader:",
                                        br,
                                        concatMap (\x -> inputLabel "number" ( x ++ "_ID") x  (x ++":")) criteriaList,
                                        br, br,
                                        submitButton "Send",
                                        br,
                                        a "/" "<- Back to Landingpage"
                                      ]
                                  ]

-- | Zeigt die Gradings eines Authors - bei Url GET "/authors/:authorname"
-- Es werden die Datein bzw. die Gradings-Txt-Files im "data/{authorname}" gelesen und ausgewertet (Median, Histogram) und das HTML gerendert
gradingAuthorHtml :: String -> ActionM()
gradingAuthorHtml authorname = do
  dataFolderPaht <- liftIO (getAuthorFolderPaht authorname)
  gradingsFiles <- liftIO (getGradingFiles dataFolderPaht)
  gradings <- liftIO (readGradingFiles gradingsFiles dataFolderPaht)
  let graderNames = map getFileName gradingsFiles
  let graderRateInts = map (\x -> read x :: [Int]) gradings
  let colMedianVales = colsToRows graderRateInts
  let mediansRow = map median colMedianVales
  let histoRow = map (histogramToPlotValue . histogram ) colMedianVales
  
  html $ T.pack $ defaultHtmlPage [  h1["Author: " ++ authorname], 
                                      if null graderRateInts 
                                        then 
                                          h2["There are no Gradings"]
                                        else divHtml "grading" [
                                                  table [
                                                    tr[
                                                      concatMap th (" " : criteriaList)
                                                    ],
                                                      concatMap renderRow (zip graderNames graderRateInts),
                                                    tr[
                                                      concatMap td ("Median " : map show mediansRow)
                                                    ],
                                                    divHtml "histogram" [
                                                      tr[
                                                        concatMap td ("Histogram " : histogramGenerateHtml histoRow  )
                                                      ]
                                                    ]
                                                  ],
                                                  br,
                                                  a "/authors" "<- Back to Authors"
                                              ]
                                  ]   

-- | Umwandelt die Histogram-Werte in ein valides Html-Table
histogramGenerateHtml :: [[[Bool]]] -> [String]
histogramGenerateHtml = map (\x -> table[ histoTr x ] )
  where histoTr      = concatMap (\x -> tr[ histoBoxRow x ])
        histoBoxRow  = concatMap ( tdBgColorBox . getColor ) 

-- | Erhalte den Folder-Path zum Author-Name" - falls nicht vorhande, wird es erstellt
getAuthorFolderPaht :: String -> IO String
getAuthorFolderPaht name = do
    let dataAuthorPath = "data/" ++ name 
    createNewDirectory dataAuthorPath 
    return dataAuthorPath

-- | Erhalte die Gradings-Files und zum gegeben Data-Folder - falls nicht vorhande, wird eine leere Liste zurück gegeben
getGradingFiles :: FilePath -> IO [String]
getGradingFiles dataFolderPaht = do
  content <- listDirectory dataFolderPaht
  let gradersLists = if null content then [] else reverse content 
  print gradersLists
  return $! gradersLists     

-- | Liest die Gradingliste aus den Gradings-Files und gib sie zurück
readGradingFiles :: [String] -> String -> IO [String]
readGradingFiles gradersLists dataFolderPaht = do
  let gradingsFileWitPath = map (\x-> dataFolderPaht ++ "/" ++ x) gradersLists
  print gradingsFileWitPath
  gradings <- liftIO (mapM readFile gradingsFileWitPath)
  return $! gradings 

-- | Die Kriterien-Liste für die Bewertungen (kann generisch erweitert werden)
criteriaList :: [String]
criteriaList = ["N1", "N2", "F1", "F2", "F3"]

-- | Rendert die Gradings-Tabelle als HTML 
renderRow :: (String, [Int]) -> String
renderRow rowEle = 
  tr[ 
    td (fst rowEle),
    concatMap (td . show)(snd rowEle)
  ]

-- | Erhalte nur die Charackters bis zum ersten Punk "."
-- Gut zum File-Extension zu entfernen. zB: getFileName "textfile.txt" == "textfile"
getFileName :: String -> String
getFileName = takeWhile (/='.') 

-- | Listet alle Authoren als eine Liste auf. 
authorsHtml :: ActionM ()
authorsHtml = do 
  authors <- liftIO readDataFolder
  html $ T.pack $ defaultHtmlPage [  
                                    h1["Authors"], 
                                    authorListView authors,
                                    br,
                                    a "/" "<- Back to Landingpage"
                                  ]
 
-- | Rendert die Authoren als Liste in HTML
authorListView :: [String] -> String
authorListView content = if null content 
    then h2["There are no Authors"]
    else 
      ul[ 
        concat $ mapWithTwo lia urls content
      ] 
      where urls = map ("/authors/" ++) content

-- | Liest alle Authoren aus als Datenliste im Ordner Data durch und gibt sie zurück
readDataFolder :: IO [String]
readDataFolder = do
    let dataPath = "data/"
    createNewDirectory dataPath 
    content <- listDirectory dataPath
    let authorsList = if null content then [] else reverse content 
    print authorsList
    return $! authorsList
