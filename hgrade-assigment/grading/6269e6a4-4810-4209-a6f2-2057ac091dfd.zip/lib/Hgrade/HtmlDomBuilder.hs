{- |
Das Modul HtmlDomBuilder enthält funktionen um HTML mit einfachen Notationen zu generieren.
-}

module Hgrade.HtmlDomBuilder where

-- | Erzeut ein gesamte Html-Seite mit allen nötigen Angaben und Metadaten. Erwartet nur noch Body-Html Werte.  
defaultHtmlPage :: [String] -> String
defaultHtmlPage bodyContent =
  htmlDocWrapper[
    htmlWrapper[
      headHtml[
        styleSheet "/static/styles.css"
        ],
      bodyHtml bodyContent
    ]
  ]

{- |
  tagNoClouser ist eine Helfermethode zum HTML-Tags zu erstellen ohne eines schliesse Tag.
  Dazu gehört: styleSheet, htmlDocWrapper, br
-}
tagNoClouser :: String -> String -> String 
tagNoClouser tagname attributes = concat ["<",tagname, attributes ,">"]

styleSheet :: String -> String
styleSheet fileUrl = tagNoClouser "link" (" rel='stylesheet' href='" ++ fileUrl ++ "'") 

htmlDocWrapper :: [String] -> String
htmlDocWrapper contents = tagNoClouser "!DOCTYPE" " html" ++ concat contents

br :: String
br = tagNoClouser "br" ""

{- |
  tagClouser ist eine Helfermethode zum HTML-Tags zu erstellen welch ein schliessendes Tag haben und es weitere HTML-Tags innerhalb ("innerHtml"), gebaut werden kann.
  Dazu gehört: htmlWrapper, headHtml, bodyHtml, divHtml, h1, h2, p, ul, li, a, lia (kombination von li und a), 
               table, tr, th, td tdAttribute (td mit Attributen), tdBgColorBox (td mit vorgefertigtem "bgcolor"-Attribute),
               formHtml (wrapper zum eine Form zu erstellen), label, input, inputLabel (kombination von input und label ) , submitButton (input mit vorgefertigtem type='submit'-Attribute definition)
-}
tagClouser :: String -> String -> String -> String
tagClouser tagname attributes innerHtml = concat ["<",tagname, attributes ,">",innerHtml,"</",tagname,">"]

htmlWrapper :: [String] -> String
htmlWrapper innerHtml = tagClouser "html" " lang='en'" (concat innerHtml)

headHtml :: [String] -> String 
headHtml metaData = tagClouser "head" "" (concat metaData)

bodyHtml :: [String] -> String
bodyHtml tags = tagClouser "body" "" (concat tags)

divHtml :: String -> [String] -> String
divHtml classList tags  = tagClouser "div" (" class='" ++ classList ++ "'") (concat tags)

h1 :: [String] -> String
h1 texts = tagClouser "h1" "" (concat texts)

h2 :: [String] -> String
h2 texts = tagClouser "h2" "" (concat texts)

p :: [String] -> String
p texts = tagClouser "p" "" (concat texts)

ul :: [String] -> String
ul lis = tagClouser "ul" "" (concat lis)

li :: [String] -> String
li lis = tagClouser "li" "" (concat lis)

a :: String -> String -> String
a url = tagClouser "a" (" href='" ++ url ++ "' ")

lia :: String -> String -> String
lia url text = li [a url text]

table :: [String] -> String
table trs = tagClouser "table" "" (concat trs)

tr :: [String] -> String
tr tds = tagClouser "tr" "" (concat tds)

th :: String -> String
th = tagClouser "th" "" 

td :: String ->String
td = tagClouser "td" "" 

tdAttribute :: String -> String ->String
tdAttribute = tagClouser "td"

tdBgColorBox :: String -> String
tdBgColorBox color = tdAttribute (" bgcolor='" ++ color ++ "' ") ""
 
formHtml :: String -> String -> [String] -> String
formHtml action method innerHtml = tagClouser "form" (" action='" ++ action ++ "' method='" ++ method ++ "' ") (concat innerHtml)

label :: String -> String -> String 
label idLabel = tagClouser "label" (" for='" ++ idLabel ++ "' ") 

input :: String -> String-> String -> String 
input typ idInput name = tagClouser "input" (" type='" ++ typ ++ "' id='" ++ idInput ++ "' name='" ++ name ++ "'") ""

inputLabel :: String -> String -> String -> String -> String
inputLabel typ idInput name labelText = concat ([
                                                  label idInput labelText,
                                                  input typ idInput name
                                                 ])

submitButton :: String -> String
submitButton value = tagClouser "input" (" type='submit' value='" ++ value ++ "'") ""


                                              