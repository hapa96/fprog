{- |
Das Modul Utilies enthält Hilfsfunktionen und funktionen zur Entwicklung des Hgrade-Moduls
-}

{-# LANGUAGE OverloadedStrings #-}


module Hgrade.Utilies where
import Data.List
import System.Random
import Control.Monad.IO.Class
import System.Directory

-- | Erstelle Ordner an angegebenen Pfad
createNewDirectory :: MonadIO m => FilePath -> m ()
createNewDirectory path = liftIO $ createDirectoryIfMissing True path

-- | Map-Funktion mit zwei Parametern
mapWithTwo :: (f -> p1 -> p2) -> [f] -> [p1] -> [p2]
mapWithTwo _ [] _ = []
mapWithTwo _ _ [] = []
mapWithTwo f (x:xs) (y:ys) = f x y : mapWithTwo f xs ys

-- | Transponiert die Werte von Listen in eine Neue
colsToRows :: [[a]] -> [[a]]
colsToRows rows = if null (head rows) then [] else map head rows : colsToRows (map tail rows) 

-- | Berechnet den Median aus einer Liste von Zahlen
median :: (Fractional a, Ord a) => [Int] -> a
median vals
    | even size = fromIntegral evenMiddleMedian / 2
    | otherwise = fromIntegral (head $ take 1 $ drop (div size 2) sortedVals)
    where size             = length vals
          sortedVals       = sort vals
          evenMiddleMedian = (\(x:y:_) -> x+y ) $ take 2 $ drop (div size 2 -1) sortedVals

-- | Generiert eine Random-Zahl zwischen 0 und 2
nrRandInt :: IO Int
nrRandInt = randomRIO (0,2) :: IO Int
    
-- | Zählt die Häufigkeit einer Zahl in einer Liste von Zahlen
countNumberInList :: Int -> [Int] -> Int
countNumberInList _ [] = 0
countNumberInList n ns = length (filter (==n) ns)

-- | Erstellt ein Histogram an der Häufigkeit der Werte
histogram :: [Int] -> (Int, Int, Int)  
histogram ls = (countNumberInList 0 ls, countNumberInList 1 ls, countNumberInList 2 ls)

-- | Kreiert ein Histogram-Matrix aus Booleans
histogramToPlotValue :: (Int, Int, Int) -> [[Bool]] 
histogramToPlotValue hist = reverse $  map(\x ->  [fstTripel hist >= x, sndTripel hist >= x, trdTripel hist >= x ]  ) numberRow
  where numberRow = [1..(fstTripel hist + sndTripel hist + trdTripel hist )]

-- | Gibt unter einer Bedingung den String-Wert "black" oder "white" zurück
getColor :: Bool -> String
getColor b = if b then "black" else "white"

-- | Gibt das erste Element eines Tripels zurück
fstTripel :: (a, b, c) -> a
fstTripel (a,_,_) = a

-- | Gibt das zweite Element eines Tripels zurück
sndTripel :: (a, b, c) -> b
sndTripel (_,b,_) = b

-- | Gibt das dritte Element eines Tripels zurück
trdTripel :: (a, b, c) -> c
trdTripel (_,_,c) = c