module Main (main) where

import Hgrade.Utilies
import Test.Tasty
import Test.Tasty.HUnit



main :: IO ()
main = defaultMain tests

tests :: TestTree
tests = testGroup "Tests" [colsToRowsTests, medianTests, histogramTest]


colsToRowsTests :: TestTree
colsToRowsTests = testGroup "colsToRows tests"
  [ 
    testCase "colsToRows of single element in list" $
      colsToRows [[7]] @?= [[7]],

    testCase "colsToRows two list small" $
      colsToRows [[1,2],[3,4]] @?= [[1,3],[2,4]],

    testCase "colsToRows two list big" $
      colsToRows [[1,2,3,4],[5,6,7,8]] @?= [[1,5],[2,6],[3,7],[4,8]],

    testCase "colsToRows many lists" $
      colsToRows [[1,2],[3,4],[5,6],[7,8],[9,10],[11,12],[13,14]] @?= [[1,3,5,7,9,11,13],[2,4,6,8,10,12,14]],

    testCase "colsToRows generic" $
      colsToRows [["a","b","c","d"],["e","f","g","h"]] @?= [["a","e"],["b","f"],["c","g"],["d","h"]]
  ]


medianTests :: TestTree
medianTests = testGroup "median tests"
  [ 
    testCase "median of 1 number in list" $
      median [1] @?= 1,

    testCase "median of 2 number - list length is even" $
      median [1,2] @?= 1.5,

    testCase "median of 3 number - list length is odd" $
      median [3,1,8] @?= 3, 

    testCase "median with high numbers" $
      median [6,0,823,2,9466,7,823,1,2] @?= 6
  ]

histogramTest :: TestTree
histogramTest = testGroup "histogram tests"
  [
      testCase "histrogram with empty list is a empty rating" $
      histogram [] @?= (0,0,0),

    testCase "histrogram with single value" $
      histogram [1] @?= (0,1,0),

    testCase "histrogram all value once" $
      histogram [1,2,0] @?= (1,1,1),

    testCase "histrogram with 6 times best rating" $
      histogram [2,2,2,2,2,2] @?= (0,0,6), 

    testCase "histrogram with random numbers - catch only number of 0, 1, 2" $
      histogram [6,0,823,2,9466,7,823,1,2] @?= (1,1,2)
  ]