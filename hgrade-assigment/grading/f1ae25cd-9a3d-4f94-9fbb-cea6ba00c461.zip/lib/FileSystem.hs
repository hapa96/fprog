{-# LANGUAGE OverloadedStrings #-}
{-|
This Module is responsible for Reading and Writing to the filesystem
-}
module FileSystem where
import System.Directory (createDirectoryIfMissing, listDirectory, doesFileExist)
import Control.Monad.IO.Class (liftIO)
import Web.Scotty (ActionM)
import qualified Data.Text.Lazy as T
import System.IO


-- |constant topleveldir to provide absolut minimum of security (that not every path in the hole system just can be accesed via URL call)
dataDir :: FilePath 
dataDir = "./data/"

-- |check if a file exists on the System
checkFile :: FilePath -> ActionM Bool
checkFile file = liftIO(doesFileExist (dataDir ++ file))

-- |Get a list from all Authors (List the folders in the Datadir)
getAuthorsFromDataDir :: ActionM [String]
getAuthorsFromDataDir = liftIO(listDirectory dataDir)

-- |Get a list from all Files witing a given folder
listDirContent :: FilePath -> ActionM [FilePath]
listDirContent dir = liftIO (listDirectory (dataDir ++ "/" ++ dir))

-- |Read the Content from a file
readFileContent :: FilePath -> ActionM String
readFileContent f = liftIO(readFile (dataDir ++ f))

-- |Read a Gradingfile within a Authorfolder and retrun the Grades as Tuple (Grader,[Grades]) 
getGradesPerGrader :: String -> FilePath -> ActionM (String,[Int])
getGradesPerGrader author gradingFile = do
    grades <- readFileContent (author ++ "/" ++ gradingFile)
    let grader = takeWhile (/= '.') gradingFile
    let stringToInt = read grades :: [Int]
    return (grader, stringToInt)

-- |Return the Grades from a File as Int List
getRawGrades :: String -> FilePath -> ActionM [Int]
getRawGrades author gradingFile = do
    grades <- readFileContent(author ++ "/" ++ gradingFile)
    return (read grades ::[Int])

-- |create a new Folder
createFolder :: FilePath -> IO()
createFolder dir = createDirectoryIfMissing True (dataDir ++ "/" ++ dir)

-- |persist a Grading to the Filesystem
writeGradesToFile :: FilePath -> FilePath -> [Int] -> IO()
writeGradesToFile dir file grades = do
    liftIO(writeFile (dataDir ++ "/" ++ dir ++ "/" ++ file ++ ".txt") (show grades))
    