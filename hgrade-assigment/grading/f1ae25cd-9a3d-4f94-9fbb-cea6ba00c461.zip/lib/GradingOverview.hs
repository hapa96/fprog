{-# LANGUAGE OverloadedStrings #-}
{-|
    This Module is responsible to collect The GradingData for an Author
    and render it as a HTML-Table
-}
module GradingOverview where
import qualified HtmlDSL as HTML
import qualified Util

-- |squash a single grading set to String list
graderDataRow :: (String,[Int]) -> [String]
graderDataRow (grader, grades) = grader : map show grades

-- |render a given dataset to a Gradingtable
renderTable :: [[String]] -> [[Int]]-> HTML.HTMLElement
renderTable dataRows rawGrades= HTML.table (HTML.tableRow(HTML.tableHeader Util.criterias) : getData dataRows ++ [histogramRow (Util.colsToRows rawGrades)])
    where getData [] = []
          getData (row:rows) = HTML.tableRow(HTML.tableData row) : getData rows

-- |calculate the Median of the given Dataset and return it a String array to be rendered by the HTML Table
medianDataRow :: [[Int]] -> [String]
medianDataRow grades = "Median" : map show (calcMedians grades) 

-- |calculte the Median of a given Dataset and return the result as List of doubles
calcMedians :: [[Int]] -> [Double]
calcMedians grades = let transformedGrades = Util.colsToRows grades 
                     in map Util.median transformedGrades

-- |Create a visual Histogram of the given List of Numbers
histogramTable :: [Int] -> String
histogramTable nums = HTML.render ( HTML.table (createHistogram (length nums) (Util.histogram nums)))

-- |Pack a Row to be diplayed in the overview table
histogramRow :: [[Int]] -> HTML.HTMLElement
histogramRow grades = HTML.tableRow(HTML.tableData["Histograms"] ++ HTML.tableData(map histogramTable grades))

-- |Deliver a List of table Rows. The Rows will contain either just Black or white cells, depening of the Calculeted Histogram Data
createHistogram :: Int -> (Int,Int,Int) -> [HTML.HTMLElement]
createHistogram max (zeros,ones,twos) = histoRow max
    where histoRow 0 = []
          histoRow n = HTML.tableRow [blackOrWhite n zeros,blackOrWhite n ones,blackOrWhite n twos] : histoRow (n-1)

-- |Helper function to decide if a Black or White Cell should be Inserted in the Row
blackOrWhite :: Int -> Int -> HTML.HTMLElement
blackOrWhite idx count = if idx > count then HTML.tableWhiteCell else HTML.tableBlackCell
