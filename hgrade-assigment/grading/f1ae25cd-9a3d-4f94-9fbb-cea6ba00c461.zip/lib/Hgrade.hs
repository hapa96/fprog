{-# LANGUAGE OverloadedStrings #-}
{-|
  main module which is the entry point for the webapp and builds the pages
-}
module Hgrade where

import qualified HtmlDSL as HTML
import qualified FileSystem as FS
import qualified GradingOverview
import qualified Util
import Web.Scotty ( ActionM, file, get, html, middleware, param, post, scotty )
import           Control.Monad.IO.Class (liftIO)
import           Network.Wai.Middleware.RequestLogger ( logStdoutDev )
import qualified Data.Text.Lazy as T

-- |main programm which starts the webserver and chains the logic
main :: IO ()
main = do
  scotty 4000 $ do
    middleware logStdoutDev
    
    get "/" indexHtml

    get "/authors" authorsHtml
      

    get "/authors/:AUTHOR_NAME" $ do
      author <- param "AUTHOR_NAME"
      gradingFiles <- FS.listDirContent author
      gradesByGrader <- mapM (FS.getGradesPerGrader author) gradingFiles
      rawGrades <- mapM (FS.getRawGrades author) gradingFiles
      let tableData = map GradingOverview.graderDataRow gradesByGrader ++ [GradingOverview.medianDataRow rawGrades]
      html (T.pack (HTML.render(
        HTML.body[
          HTML.title 1 author,
          GradingOverview.renderTable tableData rawGrades
          ])))
    
    get "/grade" gradeForm

    post "/authors" $ do
      author <- param "author"
      grader <- param "grader"
      grades <- getCriteriaParams
      let gradesAsInt = map read grades :: [Int]
      _ <- liftIO(FS.createFolder author)
      _ <- liftIO(FS.writeGradesToFile author grader gradesAsInt)
      authorsHtml


    get "/static/styles.css" $ file "static/styles.css"

-- |Static index page
indexHtml :: ActionM () 
indexHtml = html (T.pack (HTML.render(
  HTML.body[
    HTML.title 1 "Hgrade - Peergrading in Haskell",
    HTML.list[
       HTML.link "Grading Overview" "/authors",
        HTML.link "Submit Grading" "/grade"]
        ])))

-- |Genearte the Authoroverview from within the Data dir
authorsHtml :: ActionM()
authorsHtml = do
   authors <- FS.getAuthorsFromDataDir
   html (T.pack (HTML.render(
     HTML.body[
       HTML.title 1 "Authors" ,
       HTML.list (asHTMLLinks authors "authors/")
          ])))
 

-- |Generate the Grading form dynamcly from the existing criterias
gradeForm :: ActionM ()
gradeForm = html (T.pack (HTML.render(
  HTML.body[
    HTML.title 1 "Grade",
    HTML.form ([
      HTML.label "Author" "inAuthor",
      HTML.input ("text","inAuthor","author"),
      HTML.label "Grader" "inGrader",
      HTML.input ("text","inGrader","grader")] ++ (criteriasAsFormInput (tail Util.criterias) ++ [HTML.input ("submit","inSubmit","submit")])) "/authors" "post"
        ])))

-- |Helper to get a list of String as HTML links
asHTMLLinks :: [String] -> String -> [HTML.HTMLElement]
asHTMLLinks [] _ = []
asHTMLLinks (str:strgs) route = HTML.link str (route ++ str) : asHTMLLinks strgs route

-- |Helper to build dynamicaly the Grading form
criteriasAsFormInput :: [String] -> [HTML.HTMLElement]
criteriasAsFormInput [] = []
criteriasAsFormInput (crit : crits) = HTML.label crit ("in" ++ crit) : HTML.input ("text","in"++crit,crit) : criteriasAsFormInput crits

-- |Helper to read multiple Post params
getCriteriaParams :: ActionM [String]
getCriteriaParams = mapM (param . T.pack) (tail Util.criterias)
