{-|
This module is used to render simple HTML pages
Usage:  The function 'render' Transforms a 'HTMLElement' to a String.
        The page must be resulting in a Single 'HTMLElement' to be rendered.
        Container functions as 'body' and 'list' will wrap multiple Elements as 
        'title' and 'paragraphs' to a single element which can be interpreted from 'render'

-}
module HtmlDSL where
import Data.Maybe ( catMaybes )


{-|
Contract for a HTML Element. 
The Element contains the Name of the element p.e. h for title or a for link,
and a list of optional HTMLProperties
-}
data HTMLElement = HTMLElement {elementName :: String, content :: String, properties :: [Maybe HTMLProperties]} deriving (Show)

{-|
Contract for HTML Properties.
A Property must have a Key and a suitable value. P.e "href" and "/authors" for a valid Link.
-}
data HTMLProperties = HTMLProperties {key :: String, value :: String} deriving (Show)

-- ## API

-- |Wrapps the given HTMLElement in Tags
render :: HTMLElement -> String
render elem = openElement (elementName elem) (properties elem) ++ content elem ++ closeElement (elementName elem)

-- |Returns a rendered HTML body containing all Elements
body :: [HTMLElement] -> HTMLElement 
body elements = HTMLElement "body" (body' elements) [Nothing]
    where body' [] = ""
          body' (element: elements) = render element ++ body' elements

-- |Wraps all given Elements in a Unordered List and returns the List as one Element
list :: [HTMLElement] -> HTMLElement
list elements = HTMLElement "ul" (list' elements) [Nothing]
    where list' [] = ""
          list' (element: elements) = openElement "li" [Nothing] ++ render element ++ closeElement "li" ++ list' elements 

-- |Wraps all given Elements in a html Table. Elements should be 'tableRows'
table :: [HTMLElement] -> HTMLElement
table rows = HTMLElement "table" (table' rows) [Just(HTMLProperties "style" "border: 1px solid black; border-collapse: collapse")]
    where table' [] = ""
          table' (row:rows) = render row ++ table' rows
        
-- |Wraps all given Elements in a TableRow. Elements shoud be either td or th
tableRow :: [HTMLElement] -> HTMLElement
tableRow cells = HTMLElement "tr" (tableRow' cells) [Nothing]
    where tableRow' [] = ""
          tableRow' (cell:cells) = render cell ++ tableRow' cells

-- |Creats an Element of type th with the given Text
tableHeader :: [String] -> [HTMLElement]
tableHeader = map (\ th -> HTMLElement "th" th [Just(HTMLProperties "style" "border: 1px solid black; border-collapse: collapse")])

-- |Creats an Element of type td with the given Text
tableData :: [String] -> [HTMLElement]
tableData = map (\ td -> HTMLElement "td" td [Just(HTMLProperties "style" "border: 1px solid black; border-collapse: collapse")])

-- |Retrun a 20x20 sized black table cell
tableBlackCell :: HTMLElement
tableBlackCell = HTMLElement "td" "" [Just(HTMLProperties "bgcolor" "black"),Just(HTMLProperties "style" "height:20px;width:20px")]

-- |Retrun a 20x20 sized white table cell
tableWhiteCell :: HTMLElement
tableWhiteCell = HTMLElement "td" "" [Just(HTMLProperties "bgcolor" "white"),Just(HTMLProperties "style" "height:20px;width:20px;border: 1px solid black; border-collapse: collapse")]

-- |Create a Paragraphelement with the given Text
paragraph :: String -> HTMLElement
paragraph s = HTMLElement "p" s [Nothing]

-- |Create a Title Element with the Given size and Text
title :: Int -> String -> HTMLElement
title size s = HTMLElement (htmlTitleElement size) s [Nothing]

-- |Create HTML link with given description and target
link :: String -> String -> HTMLElement
link desc value = HTMLElement "a" desc [Just(HTMLProperties "href" value),Just(HTMLProperties "id" "testWiseSecondProp")]

-- |Wrap all given Elements in a Form. Elements should be of type 'label' or 'input' takes the action as Parameter
form :: [HTMLElement] -> String -> String -> HTMLElement
form elements action method = HTMLElement "form" (form' elements) [Just(HTMLProperties "action" action),Just(HTMLProperties "method" method)]
    where form' [] = []
          form' (element:elements) 
                            | elementName element == "input" = render element ++ openElement "br" [Nothing] ++ form' elements 
                            | otherwise = render element ++ form' elements

-- |Create a HTML label for a Form Input with given description and target Id
label :: String -> String-> HTMLElement
label description inputId = HTMLElement "label" description [Just(HTMLProperties "for" inputId)]

-- |Create an Input with given type, id and name
input :: (String,String,String) -> HTMLElement
input (inputType,inputID,name) = HTMLElement "input" "" [Just(HTMLProperties "type" inputType),Just(HTMLProperties "id" inputID),Just(HTMLProperties "name" name)]

-- ## "Private" Helper functions. Should not be used directly from API

-- |Helper to evalute a Title size. Validates that the title size is between 1 and 5
htmlTitleElement :: Int -> String
htmlTitleElement size
                    | size > 0 && size < 6 = "h" ++ show size
                    | otherwise = error "Invalid Title size"

-- |Wrapps the given Element in closing Tags
closeElement :: String -> String
closeElement s = "</" ++ s ++ ">"

-- |Wraps the given Element in opening Tags
openElement :: String -> [Maybe HTMLProperties] -> String
openElement s [Nothing] = "<" ++ s ++ ">"
openElement s props = "<" ++ s ++ extractProperties (catMaybes props) ++ ">"

-- |Helper function to Extract HTML-Properties
extractProperties :: [HTMLProperties] -> String
extractProperties [] = ""
extractProperties (a:as) = " " ++ concatProps a ++ extractProperties as 

-- |Helper function to render a HTML Propertie, only used by extractProperties
concatProps :: HTMLProperties -> String
concatProps prop = key prop ++ "=" ++ "\"" ++ value prop ++ "\""
