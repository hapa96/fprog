{-# LANGUAGE OverloadedStrings #-}
{-|
    This module holds commen functions
-}
module Util where
import Data.List

-- |The criterias Contains the List of the possible grades. It Must correspond with the Data in the grader.txt files
criterias :: [String]
criterias = ["","N1","N2","F1","F2","F3"]

-- |Swap columns to rows and possibly the otherway around
colsToRows :: [[a]] -> [[a]]
colsToRows ([]:_) = []
colsToRows cols = map head cols : colsToRows (map tail cols)

{-
    Calculate Median accoring following definition:

    Arrange your numbers in numerical order.
    Count how many numbers you have.
    If you have an odd number, divide by 2 and round up to get the position of the median number.
    If you have an even number, divide by 2. Go to the number in that position and average it with the number in the next higher position to get the median.
-}
median :: [Int] -> Double
median nums = if even (length nums) 
    then  let index = (length nums `div` 2) - 1
          in fromIntegral ((sort nums !! index) + (sort nums !! (index + 1))) / 2
    else  fromIntegral( sort nums !! floor (fromIntegral (length nums) / 2))

-- |Count the distribution of zeors, ones and twos in a list of Numbers. If other numbers occur in the list they will be ignored
histogram :: [Int] -> (Int,Int,Int)
histogram nums = (count 0 nums,count 1 nums,count 2 nums)

-- |Helper function to count how offten a given number occurs in a List
count :: Eq a => a -> [a] -> Int
count x =  length . filter (==x)
