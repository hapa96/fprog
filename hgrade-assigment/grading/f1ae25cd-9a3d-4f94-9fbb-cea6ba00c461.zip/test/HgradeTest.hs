module Main (main) where

import Hgrade.Example (unlines')
import Test.Tasty ( defaultMain, testGroup, TestTree )
import Test.Tasty.HUnit ( testCase, (@?=) )
import Util( colsToRows, median, histogram )



main :: IO ()
main = defaultMain tests

tests :: TestTree
tests = testGroup "Tests" [unitTests,testColToRow, testMedian,testHistogram]

unitTests :: TestTree
unitTests = testGroup "Unit tests"
  [ testCase "unlines' empty list" $
      unlines' [] @?= "",

    testCase "unlines' singleton list" $
      unlines' ["hello"] @?= "hello",

    testCase "unlines' larger list" $
      unlines' ["hello","world"] @?= "hello\nworld"
  ]

testColToRow :: TestTree
testColToRow = testGroup "ColsToRow Tests"
  [ testCase "Swap even List" $ 
      colsToRows [[1,2,3],[4,5,6]] @?= [[1,4],[2,5],[3,6]],

    testCase "Swap uneven List" $
       colsToRows [[1,2],[3,4,5]] @?= [[1,3],[2,4]]
  ]

testMedian :: TestTree
testMedian = testGroup "Median Tests"
  [ testCase "Median Even List" $ 
      median [0,2,2,0] @?= 1.0,

    testCase "Median Odd List" $
       median [3,5,1,3,1] @?= 3.0
  ]

testHistogram :: TestTree
testHistogram = testGroup "Histogram Tests"
  [ testCase "Only two" $ 
      histogram [0,2,2,0] @?= (2,0,2),

    testCase "everethin occurs" $
       histogram [0,1,1,2,0] @?= (2,2,1)
  ]